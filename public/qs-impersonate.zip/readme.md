Simple impersonator function for qlik sense. 

## Usage

1. Extract certificates from qmc and put in root folder of project
2. Set up desired user and sense host in config.js
3. run `node main.js`, the default browser should now open as you configured user.

## Disclaimer
This is not indendet for production use.