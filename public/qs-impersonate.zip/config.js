var config = {
	
	userDirectory: 'skargardsstiftelsen.local',
    userName: 'qliksense',
    engineHost: 'https://ska-srv-app01.skargardsstiftelsen.local',
    host: 'https://ska-srv-app01.skargardsstiftelsen.local:444'
};


module.exports = config;